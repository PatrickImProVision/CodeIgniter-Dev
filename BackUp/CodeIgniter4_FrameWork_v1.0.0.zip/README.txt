This folder is the target for backups created by backup-create.ps1

The zip file will be named: FrameWork Fundamental v1.0.0.zip

To create the backup, run the PowerShell script from the project root:

powershell -ExecutionPolicy Bypass -File backup-create.ps1

Or run within PowerShell:

./backup-create.ps1

The script excludes the Backup folder itself to avoid recursion.
