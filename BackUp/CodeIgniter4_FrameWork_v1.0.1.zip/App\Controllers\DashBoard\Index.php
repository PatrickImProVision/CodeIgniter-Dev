<?php

namespace App\Controllers\DashBoard;

use App\Controllers\BaseController;

class Index extends BaseController
{
    public function Index()
    {
        return 'DashBoard/Index.app route ok';
    }
}
