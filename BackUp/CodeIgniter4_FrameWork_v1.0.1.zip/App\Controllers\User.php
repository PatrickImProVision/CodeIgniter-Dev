<?php

namespace App\Controllers;

class User extends BaseController
{
    public function register()
    {
        return 'User/Register.app route ok';
    }

    public function login()
    {
        return 'User/Login.app route ok';
    }

    public function profile()
    {
        return 'User/ProFile.app route ok';
    }
}
