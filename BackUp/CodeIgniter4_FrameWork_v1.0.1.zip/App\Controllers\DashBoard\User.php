<?php

namespace App\Controllers\DashBoard;

use App\Controllers\BaseController;

class User extends BaseController
{
    public function Index()
    {
        return 'DashBoard/User.app route ok';
    }
}
