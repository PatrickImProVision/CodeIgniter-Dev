<?php

namespace App\Controllers\DashBoard;

use App\Controllers\BaseController;

class Users extends BaseController
{
    public function Index()
    {
        return 'DashBoard/Users.app route ok';
    }
}
