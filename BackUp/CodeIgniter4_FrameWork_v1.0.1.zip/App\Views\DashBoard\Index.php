<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DashBoard Index</title>
</head>
<body>
    <h1>DashBoard Index</h1>
    <p>Route: DashBoard/Index.app</p>
</body>
</html>
