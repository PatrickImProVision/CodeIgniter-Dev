<?php

// Bootstrap the application from the public folder so users can visit
// http://localhost/CodeIgniter/ without needing to include /Public in the URL.

require __DIR__ . '/Public/Index.php';


