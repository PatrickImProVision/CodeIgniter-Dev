TODO List (Saved)

Done
0. Implement Routing Map  (_AppRoot_/Index, _AppRoot_/User/*, _AppRoot_/Store/*) .app EndPoints.
In Progress
1. Implement full routing map for .php -> .app endpoints.
Still ToDo
2. Create controllers and stub actions for each mapped route.
3. Make routing portable for subfolder deployments (auto-detect base URL).
4. Add root .htaccess to forward requests to Public/.

Next
1. Adjust/rename .app route names as needed.
2. Add basic route tests or smoke checks (optional).
3. Align views/templates with route actions.


