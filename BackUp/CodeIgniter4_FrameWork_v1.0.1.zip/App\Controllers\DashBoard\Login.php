<?php

namespace App\Controllers\DashBoard;

use App\Controllers\BaseController;

class Login extends BaseController
{
    public function Index()
    {
        return 'DashBoard/Login.app route ok';
    }
}
